package com.curdoperation.exceptions;

public class UserExceptions extends RuntimeException{
  public UserExceptions(String mesage){
	  super(mesage);
  }
}
